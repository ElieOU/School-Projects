/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./templates/**/*.html",
    "./**/templates/**/*.html",
    "./core/templates/**/*.html",
    "./users/templates/**/*.html",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}