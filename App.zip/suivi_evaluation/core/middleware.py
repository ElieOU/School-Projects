# core/middleware.py
from django.shortcuts import redirect
from users.views import MembreEquipeCreateView, MembreEquipeUpdateView

class RoleAccessMiddleware:
    """
    Middleware pour filtrer les vues selon les rôles
    """
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        return self.get_response(request)

    def process_view(self, request, view_func, view_args, view_kwargs):
        if not request.user.is_authenticated:
            return None

        # Admin = accès total
        if getattr(request.user, "is_admin", False):
            return None

        # Vérification fine via permissions Django
        if hasattr(view_func, 'view_class'):
            view_class = view_func.view_class

            if issubclass(view_class, MembreEquipeCreateView) and not request.user.has_perm('users.add_membreequipe'):
                return redirect('access_denied')

            if issubclass(view_class, MembreEquipeUpdateView) and not request.user.has_perm('users.change_membreequipe'):
                return redirect('access_denied')

        # Mapping des accès par rôle
        role_access = {
            'manager': ['projet_', 'indicateur_', 'activite_'],
            'evaluator': ['evaluation_', 'indicateur_'],
            'partner': [],  # à définir selon besoin
            'member': ['projet_detail', 'activite_list'],
        }

        role_code = getattr(request.user.role, 'code', None)
        allowed_views = role_access.get(role_code, [])

        current_view = view_func.__name__

        if '*' not in allowed_views and not any(current_view.startswith(prefix) for prefix in allowed_views):
            return redirect('access_denied')

        return None
