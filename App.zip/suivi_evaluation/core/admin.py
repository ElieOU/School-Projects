from django.contrib import admin
from .models import Projet, Activite, Beneficiaire, ProjetBeneficiaire, Role, Objectif, Indicateur, Evaluation, Document, MembreEquipe, Resultat, SuiviIndicateur

@admin.register(Projet)
class ProjetAdmin(admin.ModelAdmin):
    list_display = ('nom', 'titre', 'statut', 'progression', 'owner')
    list_filter = ('statut', 'secteur')
    search_fields = ('nom', 'titre', 'owner__username')
    
    def has_view_permission(self, request, obj=None):
        return True
    
    def has_change_permission(self, request, obj=None):
        if obj and (request.user == obj.owner or request.user.is_superuser):
            return True
        return False

# Enregistrement des autres modèles
admin.site.register(Activite)
admin.site.register(Beneficiaire)
admin.site.register(ProjetBeneficiaire)
admin.site.register(Role)
admin.site.register(Objectif)
admin.site.register(Indicateur)
admin.site.register(Evaluation)
admin.site.register(Document)
admin.site.register(MembreEquipe)
admin.site.register(Resultat)
admin.site.register(SuiviIndicateur)