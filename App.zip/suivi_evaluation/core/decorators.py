# core/decorators.py
from django.core.exceptions import PermissionDenied
from functools import wraps

def role_required(*allowed_roles):
    """
    Décorateur pour vérifier le rôle de l'utilisateur.
    Exemple : @role_required('admin', 'manager')
    """
    def decorator(view_func):
        @wraps(view_func)
        def wrapper(request, *args, **kwargs):
            user = request.user

            if not user.is_authenticated:
                raise PermissionDenied

            # Admin = accès total
            if user.is_admin:
                return view_func(request, *args, **kwargs)

            # Vérification selon le rôle
            if user.role and user.role.code in allowed_roles:
                return view_func(request, *args, **kwargs)

            raise PermissionDenied
        return wrapper
    return decorator
