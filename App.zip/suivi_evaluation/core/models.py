from django.utils import timezone
from django.db import models
from django.conf import settings
from django.core.validators import MinValueValidator, MaxValueValidator
from django.db.models import Avg
from django.forms import ValidationError
from django.contrib.auth import get_user_model


class Projet(models.Model):
    nom = models.CharField(max_length=255, default='Sans nom')
    titre = models.CharField(max_length=200)
    secteur = models.CharField(max_length=100)
    date_debut = models.DateField()
    date_fin = models.DateField()
    statut = models.CharField(
        max_length=50,
        choices=[('Planifié', 'Planifié'), ('En cours', 'En cours'), ('Terminé', 'Terminé')],
        default='Planifié'
    )
    membres = models.ManyToManyField(
        settings.AUTH_USER_MODEL,
        related_name='projects_as_member',
        blank=True,
        verbose_name="Membres de l'équipe"
    )

    budget = models.DecimalField(max_digits=12, decimal_places=2)
    localisation = models.CharField(max_length=200)
    partenaires = models.TextField(blank=True)
    progression = models.FloatField(
        default=0.0,
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        help_text="Progression en pourcentage (0-100)"
    )

    # Référence simplifiée à l'utilisateur
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='owned_projects',
        null=True,
        blank=True,
        verbose_name="Propriétaire"
    )

    def update_progression(self, update_objectifs=True):
        """
        Met à jour la progression du projet en fonction des objectifs.
        Si update_objectifs=False, on évite de rappeler update_progression sur les objectifs (prévention boucle).
        """
        objectifs = self.objectifs.all()
        
        if not objectifs.exists():
            self.progression = 0.0
        else:
            total = sum(obj.progression for obj in objectifs)
            self.progression = round(total / objectifs.count(), 2)
        
        # Mise à jour du statut
        if self.progression >= 100:
            self.statut = 'Terminé'
        elif self.progression > 0:
            self.statut = 'En cours'
        else:
            self.statut = 'Planifié'
        
        self.save(update_fields=['progression', 'statut'])
        return self.progression

    def get_progression_details(self):
        """Retourne les détails complets de la progression du projet"""
        objectifs_data = []
        for objectif in self.objectifs.all():
            activites_data = []
            for activite in objectif.activites.all():
                activites_data.append({
                    'nom': activite.nom,
                    'progression': activite.progression,
                    'terminee': activite.is_terminee(),
                    'etapes_total': activite.etapes.count(),
                    'etapes_terminees': activite.etapes.filter(termine=True).count()
                })
            
            objectifs_data.append({
                'type': objectif.type,
                'description': objectif.description,
                'progression': objectif.progression,
                'activites': activites_data
            })
        
        return {
            'progression_globale': self.progression,
            'statut': self.statut,
            'objectifs': objectifs_data
        }

    def __str__(self):
        return f"{self.nom} - {self.titre}"

    class Meta:
        verbose_name = "Projet"
        verbose_name_plural = "Projets"
        permissions = [
            ("view_all_projects", "Peut voir tous les projets"),
        ]

class Objectif(models.Model):
    TYPE_CHOICES = (
        ('global', 'Global'),
        ('specifique', 'Spécifique'),
    )

    projet = models.ForeignKey(
        'Projet', 
        on_delete=models.CASCADE, 
        related_name='objectifs'
    )
    type = models.CharField(max_length=20, choices=TYPE_CHOICES)
    description = models.TextField()

    progression = models.FloatField(
        default=0.0,
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        help_text="Progression de l'objectif en pourcentage (0-100)"
    )

    def update_progression(self, update_projet=True):
        """
        Met à jour la progression basée sur les activités liées.
        Si update_projet=False, on évite de relancer la mise à jour du projet (utile pour éviter une boucle).
        """
        activites = self.activites.all()
        if not activites.exists():
            self.progression = 0.0
        else:
            total_progression = sum(a.progression for a in activites)
            self.progression = round(total_progression / activites.count(), 2)

        self.save(update_fields=['progression'])

        # Mise à jour du projet parent si demandé
        if update_projet and hasattr(self.projet, 'update_progression'):
            self.projet.update_progression(update_objectifs=False)

        return self.progression

    def __str__(self):
        return f"{self.type} - {self.description[:50]}..."

    class Meta:
        verbose_name = "Objectif"
        verbose_name_plural = "Objectifs"


class Resultat(models.Model):
    objectif = models.ForeignKey(Objectif, on_delete=models.CASCADE, related_name='resultats')
    description = models.TextField()

    def __str__(self):
        return f"Résultat - {self.description[:50]}..."

    class Meta:
        verbose_name = "Résultat"
        verbose_name_plural = "Résultats"


class Activite(models.Model):
    STATUT_CHOICES = [
        ('non_commence', 'Non commencé'),
        ('en_cours', 'En cours'),
        ('termine', 'Terminé'),
    ]
    
    objectif = models.ForeignKey(
        'Objectif', 
        on_delete=models.CASCADE, 
        related_name='activites'
    )
    nom = models.CharField(max_length=200)
    date_debut = models.DateField()
    date_fin = models.DateField()
    budget = models.DecimalField(max_digits=12, decimal_places=2)
    progression = models.FloatField(
        default=0.0,
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        help_text="Progression en pourcentage (0-100)"
    )
    statut = models.CharField(
        max_length=20,
        choices=STATUT_CHOICES,
        default='non_commence'
    )
    termine = models.BooleanField(default=False)

    def update_progression(self):
        """Calcule et met à jour la progression basée sur les étapes terminées"""
        etapes = self.etapes.all()
        total = etapes.count()
        if total == 0:
            self.progression = 0.0
        else:
            termine_count = etapes.filter(termine=True).count()
            self.progression = round((termine_count / total) * 100, 2)
        
        # Mettre à jour statut et booléen 'termine'
        if self.progression == 0:
            self.statut = 'non_commence'
            self.termine = False
        elif self.progression >= 100:
            self.statut = 'termine'
            self.termine = True
        else:
            self.statut = 'en_cours'
            self.termine = False

        super().save(update_fields=['progression', 'statut', 'termine'])
        
        # Mettre à jour la progression de l'objectif parent
        if hasattr(self.objectif, 'update_progression'):
            self.objectif.update_progression()
        
        return self.progression
    
    def is_terminee(self):
        """Vérifie si l'activité est terminée"""
        return self.progression >= 100.0

    def save(self, *args, **kwargs):
        """Override save pour s'assurer que la progression et le statut sont cohérents"""
        if not self.pk:  # Nouvelle instance, initialiser progression si nécessaire
            self.progression = self.progression or 0.0
        
        super().save(*args, **kwargs)
        self.update_progression()

    def __str__(self):
        return f"{self.nom}"

    class Meta:
        verbose_name = "Activité"
        verbose_name_plural = "Activités"


class EtapeActivite(models.Model):
    activite = models.ForeignKey(Activite, on_delete=models.CASCADE, related_name='etapes')
    description = models.CharField(max_length=255)
    termine = models.BooleanField(default=False)
    date_creation = models.DateTimeField(auto_now_add=True)
    date_modification = models.DateTimeField(auto_now=True)

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        self.activite.update_progression()

    def __str__(self):
        return f"{self.description} - {'Terminé' if self.termine else 'En cours'}"

    class Meta:
        verbose_name = "Étape d'activité"
        verbose_name_plural = "Étapes d'activité"


class Indicateur(models.Model):
    activite = models.ForeignKey(
        'Activite',
        on_delete=models.CASCADE,
        related_name='indicateurs'
    )
    nom = models.CharField(max_length=200)
    definition = models.TextField()
    cible = models.FloatField(help_text="Valeur cible à atteindre pour cet indicateur")
    methode_collecte = models.TextField()

    def get_atteinte(self):
        """
        Calcule le pourcentage d'atteinte de l'indicateur
        basé sur la dernière valeur de suivi disponible.
        """
        dernier_suivi = self.suivis.order_by('-date_suivi').first()
        if dernier_suivi and self.cible > 0:
            return round((dernier_suivi.valeur / self.cible) * 100, 2)
        return 0.0

    def is_en_retard(self, seuil=50):
        """
        Vérifie si l'indicateur est en retard.
        Par défaut : en retard si moins de 50% atteint.
        """
        return self.get_atteinte() < seuil

    def __str__(self):
        return self.nom

    def display_full(self):
        return f"{self.nom} ({self.get_atteinte()}%)"

    class Meta:
        verbose_name = "Indicateur"
        verbose_name_plural = "Indicateurs"
        unique_together = [['activite', 'nom']]


class SuiviIndicateur(models.Model):
    indicateur = models.ForeignKey(Indicateur, on_delete=models.CASCADE, related_name='suivis')
    date_suivi = models.DateField()
    valeur = models.FloatField()
    commentaire = models.TextField(blank=True)

    def __str__(self):
        return f"{self.indicateur.nom} - {self.date_suivi} - {self.valeur}"

    class Meta:
        verbose_name = "Suivi d'indicateur"
        verbose_name_plural = "Suivis d'indicateur"
        ordering = ['-date_suivi']


# Obtention du modèle User après sa définition complète
User = get_user_model()


class MembreEquipe(models.Model):
    """
    Modèle simplifié pour la gestion des membres d'équipe projet.
    """
    
    ROLE_CHOICES = (
        ('chef', 'Chef de projet'),
        ('technique', 'Expert technique'),
        ('suivi', 'Responsable suivi'),
        ('membre', 'Membre standard'),
    )
    
    # Relations
    projet = models.ForeignKey(
        Projet,  # Référence directe au lieu de string
        on_delete=models.CASCADE,
        related_name='membres_equipe',
        verbose_name="Projet associé",
        db_index=True
    )
    
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='membre_equipe_projets',
        verbose_name="Utilisateur",
        null=True,
        blank=True
    )
    
    # Champs de données
    role = models.CharField(
        max_length=20,
        choices=ROLE_CHOICES,
        default='membre',
        verbose_name="Rôle dans le projet"
    )
    
    date_ajout = models.DateTimeField(
        default=timezone.now,
        verbose_name="Date d'ajout"
    )
    
    date_modification = models.DateTimeField(
        auto_now=True,
        verbose_name="Dernière modification"
    )
    
    # Permissions simplifiées
    permissions = models.JSONField(
        default=dict,
        blank=True,
        verbose_name="Permissions spécifiques",
        help_text="Format JSON"
    )
    
    # Audit simplifié
    added_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        related_name='added_team_members',
        null=True,
        blank=True,
        verbose_name="Ajouté par"
    )
    
    class Meta:
        unique_together = ('projet', 'user')
        verbose_name = "Membre d'équipe projet"
        verbose_name_plural = "Membres d'équipe projet"
        ordering = ['projet', '-date_ajout']

    def __str__(self):
        return f"{self.get_user_display()} - {self.projet.nom} ({self.get_role_display()})"
    
    def get_user_display(self):
        """Retourne la représentation textuelle sécurisée de l'utilisateur"""
        if self.user:
            return self.user.get_full_name() or self.user.username
        return "Membre externe"

    def clean(self):
        """Validation simplifiée"""
        super().clean()
        
        # Validation : Rôle chef unique par projet
        if self.role == 'chef':
            existing_chief = MembreEquipe.objects.filter(
                projet=self.projet, 
                role='chef'
            ).exclude(pk=self.pk).exists()
            if existing_chief:
                raise ValidationError("Un chef de projet est déjà désigné")
        
        # Validation : Format des permissions
        if not isinstance(self.permissions, dict):
            raise ValidationError("Les permissions doivent être un dictionnaire JSON valide")

    @property
    def nom(self):
        """Propriété sécurisée pour le nom"""
        return self.get_user_display()
    
    @property
    def email(self):
        """Propriété sécurisée pour l'email"""
        return self.user.email if self.user else ""

    def has_perm(self, permission_codename):
        """
        Vérifie si le membre a une permission spécifique
        Soit via ses permissions personnelles, soit via son rôle
        """
        # Permissions directes
        if self.permissions.get(permission_codename, False):
            return True
        
        # Permissions basées sur le rôle
        role_permissions = {
            'chef': ['change_project', 'delete_task'],
            'technique': ['change_task', 'add_document'],
            'suivi': ['view_reports', 'add_indicator'],
        }
        return permission_codename in role_permissions.get(self.role, [])


class Beneficiaire(models.Model):
    nom = models.CharField(max_length=150)
    prenom = models.CharField(max_length=150, blank=True)
    sexe = models.CharField(max_length=10, choices=(('M', 'Masculin'), ('F', 'Féminin')), blank=True)
    date_naissance = models.DateField(null=True, blank=True)
    lieu_residence = models.CharField(max_length=200, blank=True)

    def __str__(self):
        return f"{self.nom} {self.prenom}".strip()

    class Meta:
        verbose_name = "Bénéficiaire"
        verbose_name_plural = "Bénéficiaires"


class Role(models.Model):
    nom = models.CharField(max_length=100)

    def __str__(self):
        return self.nom

    class Meta:
        verbose_name = "Rôle"
        verbose_name_plural = "Rôles"


class ProjetBeneficiaire(models.Model):
    projet = models.ForeignKey(Projet, on_delete=models.CASCADE, related_name='projet_beneficiaires')
    beneficiaire = models.ForeignKey(Beneficiaire, on_delete=models.CASCADE, related_name='projet_beneficiaires')
    date_inscription = models.DateField(auto_now_add=True)
    statut = models.CharField(max_length=100, blank=True)

    def __str__(self):
        return f"{self.beneficiaire} - {self.projet}"

    class Meta:
        verbose_name = "Bénéficiaire de projet"
        verbose_name_plural = "Bénéficiaires de projet"
        unique_together = [['projet', 'beneficiaire']]


class Evaluation(models.Model):
    projet = models.ForeignKey(Projet, on_delete=models.CASCADE, related_name='evaluations')
    TYPE_CHOICES = (
        ('auto', 'Auto-évaluation'),
        ('externe', 'Externe'),
    )
    type_evaluation = models.CharField(max_length=50, choices=TYPE_CHOICES)
    date = models.DateField()
    note = models.IntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(5)],
        default=3,
        help_text="Note entre 1 (mauvais) et 5 (excellent)"
    )
    commentaires = models.TextField(blank=True)

    def __str__(self):
        return f"Évaluation {self.note}★ - {self.projet.titre} ({self.date})"

    class Meta:
        verbose_name = "Évaluation"
        verbose_name_plural = "Évaluations"
        ordering = ['-date']


class Document(models.Model):
    projet = models.ForeignKey(Projet, on_delete=models.CASCADE, related_name='documents')
    titre = models.CharField(max_length=200)
    fichier = models.FileField(upload_to='documents/%Y/%m/%d/')
    description = models.TextField(blank=True)
    date_ajout = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.titre

    class Meta:
        verbose_name = "Document"
        verbose_name_plural = "Documents"
        ordering = ['-date_ajout']