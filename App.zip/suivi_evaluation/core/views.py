# core/views.py
import json
from django.http import JsonResponse
from django.db.models import Q, Sum, Avg
from django.shortcuts import render
from django.views import View
from django.views.decorators.http import require_http_methods
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt
from functools import wraps
from django.urls import reverse, reverse_lazy
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.contrib import messages
from django.core.exceptions import PermissionDenied

from users.models import CustomUser
from .models import (
    EtapeActivite, Projet, Objectif, Resultat, Activite, Indicateur, SuiviIndicateur, 
    MembreEquipe, Beneficiaire, Role, ProjetBeneficiaire, Evaluation, Document
)
from django.views.generic import TemplateView
from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpResponse
from .models import Activite, Indicateur, SuiviIndicateur, MembreEquipe, Beneficiaire, Role, ProjetBeneficiaire, Evaluation, Document
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from django.contrib.auth.decorators import login_required
import matplotlib.pyplot as plt
from io import BytesIO
import docx
import requests
from django.contrib.auth import get_user_model
from django.utils.crypto import get_random_string
from reportlab.pdfgen import canvas
from users.forms import EvaluationForm, MembreEquipeForm
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle
from django.http import HttpResponse
from django.http import HttpResponse
from django.template.loader import get_template
from xhtml2pdf import pisa
import pandas as pd
from io import BytesIO
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
import docx
from openpyxl import Workbook

from core import models

# Pour un document ind

def handle_theme_selection(request):
    """Gère la sélection du thème et renvoie une réponse JSON"""
    theme = request.POST.get('theme', 'light')
    response = JsonResponse({'status': 'success', 'theme': theme})
    response.set_cookie(
        'theme', 
        theme, 
        max_age=365*24*60*60,  # 1 an
        httponly=True,
        samesite='Lax'
    )
    return response

@require_http_methods(["POST"])
@csrf_exempt
def set_theme(request):
    """
    Vue pour changer le thème de l'interface
    Accepte uniquement les requêtes POST
    """
    return handle_theme_selection(request)

def public_view(view_func):
    """Décorateur pour les vues publiques"""
    @wraps(view_func)
    def wrapper(request, *args, **kwargs):
        # Ajoutez ici une logique commune aux vues publiques
        return view_func(request, *args, **kwargs)
    return wrapper

@public_view
def home_view(request):
    """
    Vue de la page d'accueil publique ou redirection vers login/dashboard
    """
    # Si l'utilisateur est connecté → dashboard
    if request.user.is_authenticated:
        return redirect('dashboard')
    
    # Sinon → page de login
    return redirect('login')


@login_required
def dashboard_view(request):
    user = request.user
    projets = Projet.objects.filter(owner=user)
    
    # Calcul des statistiques
    total_budget = projets.aggregate(total=Sum('budget'))['total'] or 0
    projets_termines = projets.filter(statut='Terminé').count()
    projets_en_cours = projets.filter(statut='En cours').count()
    projets_en_retard = projets.filter(statut='En retard').count()
    
    # Récupération des indicateurs
    indicateurs = Indicateur.objects.filter(activite__objectif__projet__owner=user)
    
    # Calcul des indicateurs atteints (progression >= 100)
    indicateurs_atteints = []
    indicateurs_encours = []
    indicateurs_retard = []
    
    for indicateur in indicateurs:
        atteinte = indicateur.get_atteinte()  # Supposons que cette méthode existe
        if atteinte >= 100:
            indicateurs_atteints.append(indicateur)
        elif atteinte > 0:
            indicateurs_encours.append(indicateur)
        else:
            indicateurs_retard.append(indicateur)
    
    context = {
        'stats_globales': {
            'total_projets': projets.count(),
            'projets_termines': projets_termines,
            'projets_en_cours': projets_en_cours,
            'projets_en_retard': projets_en_retard,
            'progression_moyenne': projets.aggregate(avg=Avg('progression'))['avg'] or 0,
        },
        'total_budget': total_budget,
        'recent_projects': projets.order_by('-date_debut')[:5],
        'recent_activities': Activite.objects.filter(objectif__projet__owner=user).order_by('-date_debut')[:5],
        'indicateurs_atteints': indicateurs_atteints,
        'indicateurs_encours': indicateurs_encours,
        'indicateurs_retard': indicateurs_retard,
        'indicateurs_atteints_count': len(indicateurs_atteints),
        'indicateurs_encours_count': len(indicateurs_encours),
        'indicateurs_retard_count': len(indicateurs_retard),
        'indicateurs_count': indicateurs.count(),
    }
    
    return render(request, 'core/dashboard.html', context)


class ProjetListView(LoginRequiredMixin, ListView):
    model = Projet
    template_name = 'users/projet_list.html'
    context_object_name = 'projets'

    def get_queryset(self):
        # Retourne tous les projets sans filtre
        return Projet.objects.all()

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        projets = self.get_queryset()  # Utilise get_queryset() qui retourne tous les projets
        
        # Calcul des statistiques
        total_budget = projets.aggregate(total=Sum('budget'))['total'] or 0
        
        # Projets par statut
        projets_en_cours = projets.filter(statut='En cours')
        projets_termines = projets.filter(statut='Terminé')
        projets_autres = projets.exclude(statut__in=['En cours', 'Terminé'])
        
        # Projets récents (5 derniers)
        projets_recents = projets.order_by('-date_debut')[:5]
        
        # Ajout au contexte
        context.update({
            'total_budget': total_budget,
            'projets_en_cours': projets_en_cours,
            'projets_termines': projets_termines,
            'projets_autres': projets_autres,
            'projets_recents': projets_recents,
            'projets_count': projets.count(),
            'projets_en_cours_count': projets_en_cours.count(),
            'projets_termines_count': projets_termines.count(),
        })
        
        return context
    
    

class ProjetDetailView(LoginRequiredMixin, DetailView):
    model = Projet
    template_name = 'users/projet_detail.html'
    context_object_name = 'projet'

    def get_queryset(self):
        return Projet.objects.filter(owner=self.request.user)

class ProjetCreateView(LoginRequiredMixin, CreateView):
    model = Projet
    fields = ['nom', 'titre', 'secteur', 'date_debut', 'date_fin', 'budget', 'localisation', 'partenaires', 'statut']
    template_name = 'users/projet_form.html'
    success_url = reverse_lazy('projet_list')

    def form_valid(self, form):
        form.instance.owner = self.request.user
        return super().form_valid(form)

class ProjetUpdateView(LoginRequiredMixin, UpdateView):
    model = Projet
    fields = ['nom', 'titre', 'secteur', 'date_debut', 'date_fin', 'budget', 'localisation', 'partenaires', 'statut']
    template_name = 'users/projet_form.html'
    success_url = reverse_lazy('projet_list')

    def get_queryset(self):
        return Projet.objects.filter(owner=self.request.user)

class ProjetDeleteView(LoginRequiredMixin, DeleteView):
    model = Projet
    template_name = 'users/projet_confirm_delete.html'
    success_url = reverse_lazy('projet_list')

    def get_queryset(self):
        return Projet.objects.filter(owner=self.request.user)



# --- OBJECTIF ---
class ObjectifListView(LoginRequiredMixin, ListView):
    model = Objectif
    template_name = 'core/objectif_list.html'
    context_object_name = 'objectifs'

    def get_queryset(self):
        return Objectif.objects.filter(projet__owner=self.request.user)

class ObjectifDetailView(LoginRequiredMixin, DetailView):
    model = Objectif
    template_name = 'core/objectif_detail.html'
    context_object_name = 'objectif'

class ObjectifCreateView(LoginRequiredMixin, CreateView):
    model = Objectif
    fields = ['projet', 'type', 'description']
    template_name = 'core/objectif_form.html'
    success_url = reverse_lazy('objectif_list')

    def get_form(self, *args, **kwargs):
        form = super().get_form(*args, **kwargs)
        form.fields['projet'].queryset = Projet.objects.filter(owner=self.request.user)
        return form

class ObjectifUpdateView(LoginRequiredMixin, UpdateView):
    model = Objectif
    fields = ['projet', 'type', 'description']
    template_name = 'core/objectif_form.html'
    success_url = reverse_lazy('objectif_list')

    def get_queryset(self):
        return Objectif.objects.filter(projet__owner=self.request.user)

class ObjectifDeleteView(LoginRequiredMixin, DeleteView):
    model = Objectif
    template_name = 'core/objectif_confirm_delete.html'
    success_url = reverse_lazy('objectif_list')

    def get_queryset(self):
        return Objectif.objects.filter(projet__owner=self.request.user)

# --- RESULTAT ---
class ResultatListView(LoginRequiredMixin, ListView):
    model = Resultat
    template_name = 'users/resultat_list.html'
    context_object_name = 'resultats'

    def get_queryset(self):
        return Resultat.objects.filter(objectif__projet__owner=self.request.user)

class ResultatDetailView(LoginRequiredMixin, DetailView):
    model = Resultat
    template_name = 'users/resultat_detail.html'
    context_object_name = 'resultat'

class ResultatCreateView(LoginRequiredMixin, CreateView):
    model = Resultat
    fields = ['objectif', 'description']
    template_name = 'users/resultat_form.html'
    success_url = reverse_lazy('resultat_list')

    def get_form(self, *args, **kwargs):
        form = super().get_form(*args, **kwargs)
        form.fields['objectif'].queryset = Objectif.objects.filter(projet__owner=self.request.user)
        return form

class ResultatUpdateView(LoginRequiredMixin, UpdateView):
    model = Resultat
    fields = ['objectif', 'description']
    template_name = 'users/resultat_form.html'
    success_url = reverse_lazy('resultat_list')

    def get_queryset(self):
        return Resultat.objects.filter(objectif__projet__owner=self.request.user)

class ResultatDeleteView(LoginRequiredMixin, DeleteView):
    model = Resultat
    template_name = 'users/resultat_confirm_delete.html'
    success_url = reverse_lazy('resultat_list')

    def get_queryset(self):
        return Resultat.objects.filter(objectif__projet__owner=self.request.user)

# --- ACTIVITE ---
class ActiviteListView(LoginRequiredMixin, ListView):
    model = Activite
    template_name = 'core/activite_list.html'
    context_object_name = 'activites'

    def get_queryset(self):
        return Activite.objects.filter(objectif__projet__owner=self.request.user)

class ActiviteDetailView(LoginRequiredMixin, DetailView):
    model = Activite
    template_name = 'core/activite_detail.html'
    context_object_name = 'activite'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['etapes'] = self.object.etapes.all().order_by('-date_creation')
        return context
class ActiviteCreateView(LoginRequiredMixin, CreateView):
    model = Activite
    fields = ['objectif', 'nom', 'date_debut', 'date_fin', 'budget']
    template_name = 'core/activite_form.html'
    success_url = reverse_lazy('activite_list')

    def get_form(self, *args, **kwargs):
        form = super().get_form(*args, **kwargs)
        # Filtrer les objectifs par propriétaire et ordonner par projet
        form.fields['objectif'].queryset = Objectif.objects.filter(
            projet__owner=self.request.user
        ).select_related('projet').order_by('projet__nom', 'type')
        return form

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # Ajouter tous les objectifs pour affichage supplémentaire si nécessaire
        context['objectifs'] = Objectif.objects.filter(
            projet__owner=self.request.user
        ).select_related('projet')
        return context

    def form_valid(self, form):
        form.instance.created_by = self.request.user
        response = super().form_valid(form)
        
        # Gestion des étapes
        self._handle_etapes()
        return response

    def _handle_etapes(self):
        etapes_data = self.request.POST.get('etapes', '[]')
        etapes_existantes = self.request.POST.getlist('etapes_existantes')
        
        try:
            nouvelles_etapes = json.loads(etapes_data)
            self.object.etapes.exclude(id__in=etapes_existantes).delete()
            
            for etape_data in nouvelles_etapes:
                EtapeActivite.objects.create(
                    activite=self.object,
                    description=etape_data['description']
                )
        except json.JSONDecodeError:
            pass

class ActiviteUpdateView(LoginRequiredMixin, UpdateView):
    model = Activite
    fields = ['objectif', 'nom', 'date_debut', 'date_fin', 'budget']
    template_name = 'core/activite_form.html'
    success_url = reverse_lazy('activite_list')

    def get_queryset(self):
        return Activite.objects.filter(objectif__projet__owner=self.request.user)

    def get_form(self, *args, **kwargs):
        form = super().get_form(*args, **kwargs)
        form.fields['objectif'].queryset = Objectif.objects.filter(
            projet__owner=self.request.user
        ).select_related('projet').order_by('projet__nom', 'type')
        return form

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['objectifs'] = Objectif.objects.filter(
            projet__owner=self.request.user
        ).select_related('projet')
        return context

    def form_valid(self, form):
        response = super().form_valid(form)
        self._handle_etapes()
        return response

    def _handle_etapes(self):
        # Même logique que dans CreateView
        etapes_data = self.request.POST.get('etapes', '[]')
        etapes_existantes = self.request.POST.getlist('etapes_existantes')
        
        try:
            nouvelles_etapes = json.loads(etapes_data)
            self.object.etapes.exclude(id__in=etapes_existantes).delete()
            
            for etape_data in nouvelles_etapes:
                EtapeActivite.objects.create(
                    activite=self.object,
                    description=etape_data['description']
                )
        except json.JSONDecodeError:
            pass
        
        
class ActiviteDeleteView(LoginRequiredMixin, DeleteView):
    model = Activite
    template_name = 'core/activite_confirm_delete.html'
    success_url = reverse_lazy('activite_list')

    def get_queryset(self):
        return Activite.objects.filter(objectif__projet__owner=self.request.user)
    
    
class EtapeCreateView(LoginRequiredMixin, CreateView):
    model = EtapeActivite
    fields = ['description']
    template_name = 'core/etape_form.html'

    def form_valid(self, form):
        activite = get_object_or_404(Activite, pk=self.kwargs['activite_pk'])
        form.instance.activite = activite
        return super().form_valid(form)

    def get_success_url(self):
        return reverse('activite_detail', kwargs={'pk': self.kwargs['activite_pk']})

class EtapeToggleView(LoginRequiredMixin, View):
    def post(self, request, *args, **kwargs):
        etape = get_object_or_404(EtapeActivite, pk=kwargs['pk'])
        etape.termine = not etape.termine
        etape.save()
        
        # Mettre à jour la progression de l'activité parente
        activite = etape.activite
        activite.update_progression()
        
        return JsonResponse({
            'termine': etape.termine,
            'progression': activite.progression,
            'activite_id': activite.id,
            'projet_progression': activite.objectif.projet.progression  # Ajouté
        })

        

# --- INDICATEUR ---
# Liste des indicateurs pour l'utilisateur connecté
class IndicateurListView(LoginRequiredMixin, ListView):
    model = Indicateur
    template_name = 'core/indicateur_list.html'
    context_object_name = 'indicateurs'

    def get_queryset(self):
        # Filtre par projets de l'utilisateur connecté
        return Indicateur.objects.filter(activite__objectif__projet__owner=self.request.user)

# Création d'un indicateur
class IndicateurCreateView(LoginRequiredMixin, CreateView):
    model = Indicateur
    fields = ['activite', 'nom', 'definition', 'cible', 'methode_collecte']
    template_name = 'users/indicateur_form.html'
    success_url = reverse_lazy('indicateur_list')

    def get_form(self, *args, **kwargs):
        form = super().get_form(*args, **kwargs)
        # Ne proposer que les activités des projets de l'utilisateur
        form.fields['activite'].queryset = Activite.objects.filter(objectif__projet__owner=self.request.user)
        return form

# Modification d'un indicateur
class IndicateurUpdateView(LoginRequiredMixin, UpdateView):
    model = Indicateur
    fields = ['activite', 'nom', 'definition', 'cible', 'methode_collecte']
    template_name = 'users/indicateur_form.html'
    success_url = reverse_lazy('indicateur_list')

    def get_queryset(self):
        return Indicateur.objects.filter(activite__objectif__projet__owner=self.request.user)

# Suppression d'un indicateur
class IndicateurDeleteView(LoginRequiredMixin, DeleteView):
    model = Indicateur
    template_name = 'users/indicateur_confirm_delete.html'
    success_url = reverse_lazy('indicateur_list')

    def get_queryset(self):
        return Indicateur.objects.filter(activite__objectif__projet__owner=self.request.user)
  
  
class SuiviDashboardView(LoginRequiredMixin, TemplateView):
    template_name = 'core/suivi_dashboard.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        user = self.request.user

        # Récupérer tous les projets de l'utilisateur et mettre à jour leur progression
        projets = Projet.objects.filter(owner=user)
        for projet in projets:
            projet.update_progression()
        context['projets'] = projets

        # Statistiques globales
        context['stats_globales'] = {
            'total_projets': projets.count(),
            'projets_termines': projets.filter(statut='Terminé').count(),
            'projets_en_cours': projets.filter(statut='En cours').count(),
            'progression_moyenne': projets.aggregate(
                avg_progression=models.Avg('progression')
            )['avg_progression'] or 0,
        }

        # Si un projet est sélectionné
        projet_id = self.request.GET.get('projet')
        if projet_id:
            selected_projet = get_object_or_404(Projet, id=projet_id, owner=user)
            context['selected_projet'] = selected_projet
            context['progression_details'] = selected_projet.get_progression_details()

            # Récupérer les activités du projet
            activites = Activite.objects.filter(objectif__projet=selected_projet)

            # Récupérer les indicateurs liés à ces activités
            indicateurs = Indicateur.objects.filter(activite__in=activites).select_related(
                'activite',
                'activite__objectif'
            )

            context['indicateurs'] = indicateurs

            # Catégorisation
            context['indicateurs_atteints'] = [i for i in indicateurs if i.get_atteinte() >= 100]
            context['indicateurs_encours'] = [i for i in indicateurs if 0 < i.get_atteinte() < 100]
            context['indicateurs_retard'] = [i for i in indicateurs if i.is_en_retard()]

        return context



# --- SUIVIINDICATEUR ---


class SuiviIndicateurListView(LoginRequiredMixin, ListView):
    model = SuiviIndicateur
    template_name = 'users/suiviindicateur_list.html'
    context_object_name = 'suivis'

    def get_queryset(self):
        # Correction: Utiliser la bonne chaîne de relations
        return SuiviIndicateur.objects.filter(
            indicateur__activite__objectif__projet__owner=self.request.user
        ).select_related(
            'indicateur__activite__objectif__projet'
        ).order_by('-date_suivi')



class SuiviIndicateurDetailView(LoginRequiredMixin, DetailView):
    model = SuiviIndicateur
    template_name = 'users/suiviindicateur_detail.html'
    context_object_name = 'suivi'

    def get_queryset(self):
        return SuiviIndicateur.objects.filter(
            indicateur__activite__objectif__projet__owner=self.request.user
        ).select_related(
            'indicateur__activite__objectif__projet'
        )


class SuiviIndicateurCreateView(LoginRequiredMixin, CreateView):
    model = SuiviIndicateur
    fields = ['indicateur', 'date_suivi', 'valeur', 'commentaire']
    template_name = 'users/suiviindicateur_form.html'
    success_url = reverse_lazy('suivi_list')

    def get_form(self, *args, **kwargs):
        form = super().get_form(*args, **kwargs)
        form.fields['indicateur'].queryset = Indicateur.objects.filter(
            activite__objectif__projet__owner=self.request.user
        ).select_related('activite__objectif__projet')
        return form



    def form_valid(self, form):
        response = super().form_valid(form)
        indicateur = form.instance.indicateur
        if hasattr(indicateur.activite, "update_progression"):
            indicateur.activite.update_progression()
        return response


class SuiviIndicateurUpdateView(LoginRequiredMixin, UpdateView):
    model = SuiviIndicateur
    fields = ['indicateur', 'date_suivi', 'valeur', 'commentaire']
    template_name = 'users/suiviindicateur_form.html'
    success_url = reverse_lazy('suivi_list')

    def get_queryset(self):
        return SuiviIndicateur.objects.filter(
            indicateur__activite__objectif__projet__owner=self.request.user
        ).select_related('indicateur__activite__objectif__projet')

    def get_form(self, *args, **kwargs):
        form = super().get_form(*args, **kwargs)
        form.fields['indicateur'].queryset = Indicateur.objects.filter(
            activite__objectif__projet__owner=self.request.user
        ).select_related('activite__objectif__projet')
        return form

    def form_valid(self, form):
        response = super().form_valid(form)
        indicateur = form.instance.indicateur
        if hasattr(indicateur.activite, "update_progression"):
            indicateur.activite.update_progression()
        return response


class SuiviIndicateurDeleteView(LoginRequiredMixin, DeleteView):
    model = SuiviIndicateur
    template_name = 'users/suiviindicateur_confirm_delete.html'
    success_url = reverse_lazy('suiviindicateur_list')

    def get_queryset(self):
        return SuiviIndicateur.objects.filter(
            indicateur__activite__resultat__objectif__projet__owner=self.request.user
        )
   
       
       
class ProjetProgressionView(LoginRequiredMixin, DetailView):
    model = Projet
    template_name = 'core/projet_progression.html'
    context_object_name = 'projet'
    
    def get_queryset(self):
        return Projet.objects.filter(owner=self.request.user)
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        projet = self.get_object()
        
        # Mettre à jour la progression avant affichage
        projet.update_progression()
        
        # Récupérer les détails de progression
        context['progression_details'] = projet.get_progression_details()
        
        # Statistiques générales
        context['stats'] = {
            'total_objectifs': projet.objectifs.count(),
            'total_activites': sum(obj.activites.count() for obj in projet.objectifs.all()),
            'activites_terminees': sum(
                obj.activites.filter(progression=100.0).count() 
                for obj in projet.objectifs.all()
            ),
            'total_etapes': sum(
                sum(act.etapes.count() for act in obj.activites.all()) 
                for obj in projet.objectifs.all()
            ),
            'etapes_terminees': sum(
                sum(act.etapes.filter(termine=True).count() for act in obj.activites.all()) 
                for obj in projet.objectifs.all()
            ),
        }
        
        return context


class UpdateProgressionView(LoginRequiredMixin, View):
    def post(self, request, *args, **kwargs):
        action = request.POST.get('action')
        item_id = request.POST.get('item_id')
        
        if action == 'toggle_etape':
            etape = get_object_or_404(EtapeActivite, pk=item_id)
            # Vérifier que l'utilisateur a le droit
            if etape.activite.objectif.projet.owner != request.user:
                return JsonResponse({'error': 'Unauthorized'}, status=403)
            
            etape.termine = not etape.termine
            etape.save()
            
            # Mettre à jour les progressions
            activite = etape.activite
            activite.update_progression()
            
            return JsonResponse({
                'success': True,
                'etape_termine': etape.termine,
                'activite_progression': activite.progression,
                'objectif_progression': activite.objectif.progression,
                'projet_progression': activite.objectif.projet.progression,
                'projet_statut': activite.objectif.projet.statut
            })
        
        elif action == 'mark_activite_complete':
            activite = get_object_or_404(Activite, pk=item_id)
            if activite.objectif.projet.owner != request.user:
                return JsonResponse({'error': 'Unauthorized'}, status=403)
            
            # Marquer toutes les étapes comme terminées
            activite.etapes.update(termine=True)
            activite.update_progression()
            
            return JsonResponse({
                'success': True,
                'activite_progression': activite.progression,
                'objectif_progression': activite.objectif.progression,
                'projet_progression': activite.objectif.projet.progression,
                'projet_statut': activite.objectif.projet.statut
            })
        
        return JsonResponse({'error': 'Invalid action'}, status=400)










        #--- MEMBREEQUIPE ---
class TeamAccessMixin(UserPassesTestMixin):
    """Mixin de base pour les vues d'équipe"""
    def test_func(self):
        user = self.request.user
        if user.is_admin:  # Retirer les parenthèses ici
            return True
        
        # Pour les opérations sur un objet spécifique
        if hasattr(self, 'get_object'):
            obj = self.get_object()
            return obj.projet.created_by == user or user in obj.projet.membres_equipe.all()
        
        return user.can_manage_team()
    
    def handle_no_permission(self):
        messages.error(self.request, "Accès refusé : permissions insuffisantes")
        raise PermissionDenied



class MembreEquipeBaseView(LoginRequiredMixin, TeamAccessMixin):
    model = MembreEquipe
    context_object_name = 'membre'
    pk_url_kwarg = 'pk'

class MembreEquipeListView(MembreEquipeBaseView, ListView):
    template_name = 'core/membre_equipe_list.html'
    paginate_by = 15

    def get_queryset(self):
        queryset = super().get_queryset()
        if not self.request.user.is_admin:  # Retirer les parenthèses ici
            queryset = queryset.filter(
                Q(projet__created_by=self.request.user) |
                Q(projet__membres_equipe__user=self.request.user)
            ).distinct()
        return queryset.select_related('user', 'projet', 'added_by')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        user = self.request.user
        context['can_add_member'] = user.is_staff or user.is_superuser  # Utilise les champs natifs de Django
        return context

class MembreEquipeCreateView(MembreEquipeBaseView, CreateView):
    form_class = MembreEquipeForm
    template_name = 'core/membre_equipe_form.html'
    success_url = reverse_lazy('membre_equipe_list')

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs.update({
            'user': self.request.user,
            'projet_id': self.kwargs.get('projet_id')
        })
        return kwargs

    def form_valid(self, form):
        form.instance.added_by = self.request.user
        response = super().form_valid(form)
        messages.success(
            self.request, 
            f"{form.instance.user.get_full_name()} a été ajouté à l'équipe avec succès."
        )
        return response

class MembreEquipeUpdateView(MembreEquipeBaseView, UpdateView):
    form_class = MembreEquipeForm
    template_name = 'core/membre_equipe_form.html'
    success_url = reverse_lazy('membre_equipe_list')

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs['user'] = self.request.user
        return kwargs

    def form_valid(self, form):
        response = super().form_valid(form)
        messages.success(self.request, "Membre mis à jour avec succès.")
        return response

class MembreEquipeDeleteView(MembreEquipeBaseView, DeleteView):
    template_name = 'core/membre_equipe_confirm_delete.html'
    success_url = reverse_lazy('membre_equipe_list')

    def delete(self, request, *args, **kwargs):
        member = self.get_object()
        member_name = member.user.get_full_name()
        response = super().delete(request, *args, **kwargs)
        messages.success(request, f"{member_name} a été retiré de l'équipe.")
        return response

class ProjectTeamView(LoginRequiredMixin, DetailView):
    model = Projet
    template_name = 'core/project_team.html'
    context_object_name = 'projet'

    def get_queryset(self):
        queryset = super().get_queryset()
        if not self.request.user.is_admin():
            queryset = queryset.filter(
                Q(created_by=self.request.user) | 
                Q(membres_equipe__user=self.request.user)
            ).distinct()
        return queryset.prefetch_related('membres_equipe__user')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        project = self.object
        context.update({
            'team_members': project.membres_equipe.all(),
            'can_manage_team': self.request.user.can_manage_team() and 
                              (self.request.user.is_admin() or 
                               project.created_by == self.request.user)
        })
        return context

# --- BENEFICIAIRE ---
class BeneficiaireListView(LoginRequiredMixin, ListView):
    model = Beneficiaire
    template_name = 'users/beneficiaire_list.html'
    context_object_name = 'beneficiaires'

class BeneficiaireDetailView(LoginRequiredMixin, DetailView):
    model = Beneficiaire
    template_name = 'users/beneficiaire_detail.html'
    context_object_name = 'beneficiaire'

class BeneficiaireCreateView(LoginRequiredMixin, CreateView):
    model = Beneficiaire
    fields = ['nom', 'prenom', 'sexe', 'date_naissance', 'lieu_residence']
    template_name = 'users/beneficiaire_form.html'
    success_url = reverse_lazy('beneficiaire_list')

class BeneficiaireUpdateView(LoginRequiredMixin, UpdateView):
    model = Beneficiaire
    fields = ['nom', 'prenom', 'sexe', 'date_naissance', 'lieu_residence']
    template_name = 'users/beneficiaire_form.html'
    success_url = reverse_lazy('beneficiaire_list')

class BeneficiaireDeleteView(LoginRequiredMixin, DeleteView):
    model = Beneficiaire
    template_name = 'users/beneficiaire_confirm_delete.html'
    success_url = reverse_lazy('beneficiaire_list')

# --- ROLE ---
class RoleListView(LoginRequiredMixin, ListView):
    model = Role
    template_name = 'users/role_list.html'
    context_object_name = 'roles'

class RoleDetailView(LoginRequiredMixin, DetailView):
    model = Role
    template_name = 'users/role_detail.html'
    context_object_name = 'role'

class RoleCreateView(LoginRequiredMixin, CreateView):
    model = Role
    fields = ['nom']
    template_name = 'users/role_form.html'
    success_url = reverse_lazy('role_list')

class RoleUpdateView(LoginRequiredMixin, UpdateView):
    model = Role
    fields = ['nom']
    template_name = 'users/role_form.html'
    success_url = reverse_lazy('role_list')

class RoleDeleteView(LoginRequiredMixin, DeleteView):
    model = Role
    template_name = 'users/role_confirm_delete.html'
    success_url = reverse_lazy('role_list')

# --- PROJETBENEFICIAIRE ---
class ProjetBeneficiaireListView(LoginRequiredMixin, ListView):
    model = ProjetBeneficiaire
    template_name = 'users/projetbeneficiaire_list.html'
    context_object_name = 'projet_beneficiaires'

    def get_queryset(self):
        return ProjetBeneficiaire.objects.filter(projet__owner=self.request.user)

class ProjetBeneficiaireDetailView(LoginRequiredMixin, DetailView):
    model = ProjetBeneficiaire
    template_name = 'users/projetbeneficiaire_detail.html'
    context_object_name = 'projet_beneficiaire'

class ProjetBeneficiaireCreateView(LoginRequiredMixin, CreateView):
    model = ProjetBeneficiaire
    fields = ['projet', 'beneficiaire', 'statut']
    template_name = 'users/projetbeneficiaire_form.html'
    success_url = reverse_lazy('projetbeneficiaire_list')

    def get_form(self, *args, **kwargs):
        form = super().get_form(*args, **kwargs)
        form.fields['projet'].queryset = Projet.objects.filter(owner=self.request.user)
        form.fields['beneficiaire'].queryset = Beneficiaire.objects.all()
        return form

class ProjetBeneficiaireUpdateView(LoginRequiredMixin, UpdateView):
    model = ProjetBeneficiaire
    fields = ['projet', 'beneficiaire', 'statut']
    template_name = 'users/projetbeneficiaire_form.html'
    success_url = reverse_lazy('projetbeneficiaire_list')

    def get_queryset(self):
        return ProjetBeneficiaire.objects.filter(projet__owner=self.request.user)

class ProjetBeneficiaireDeleteView(LoginRequiredMixin, DeleteView):
    model = ProjetBeneficiaire
    template_name = 'users/projetbeneficiaire_confirm_delete.html'
    success_url = reverse_lazy('projetbeneficiaire_list')

    def get_queryset(self):
        return ProjetBeneficiaire.objects.filter(projet__owner=self.request.user)
    
# --- EVALUATION ---
class EvaluationListView(LoginRequiredMixin, ListView):
    model = Evaluation
    template_name = 'core/evaluation_list.html'
    context_object_name = 'evaluations'

    def get_queryset(self):
        return Evaluation.objects.filter(projet__owner=self.request.user)

class EvaluationDetailView(LoginRequiredMixin, DetailView):
    model = Evaluation
    template_name = 'users/evaluation_detail.html'
    context_object_name = 'evaluation'

class EvaluationCreateView(LoginRequiredMixin, CreateView):
    model = Evaluation
    form_class = EvaluationForm
    template_name = 'users/evaluation_form.html'
    success_url = reverse_lazy('evaluation_list')

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs['request'] = self.request
        return kwargs

class EvaluationUpdateView(LoginRequiredMixin, UpdateView):
    model = Evaluation
    form_class = EvaluationForm
    template_name = 'users/evaluation_form.html'
    success_url = reverse_lazy('evaluation_list')

    def get_queryset(self):
        # Filtre les évaluations où l'utilisateur est soit owner soit membre du projet associé
        return Evaluation.objects.filter(
            Q(projet__owner=self.request.user) | 
            Q(projet__membres=self.request.user)
        ).distinct()

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs['request'] = self.request
        return kwargs


class EvaluationDeleteView(LoginRequiredMixin, DeleteView):
    model = Evaluation
    template_name = 'users/evaluation_confirm_delete.html'
    success_url = reverse_lazy('evaluation_list')

    def get_queryset(self):
        return Evaluation.objects.filter(projet__owner=self.request.user)
    
# --- DOCUMENT ---
class DocumentListView(LoginRequiredMixin, ListView):
    model = Document
    template_name = 'users/document_list.html'
    context_object_name = 'documents'

    def get_queryset(self):
        return Document.objects.filter(projet__owner=self.request.user)

class DocumentDetailView(LoginRequiredMixin, DetailView):
    model = Document
    template_name = 'users/document_detail.html'
    context_object_name = 'document'

class DocumentCreateView(LoginRequiredMixin, CreateView):
    model = Document
    fields = ['projet', 'titre', 'fichier', 'description']
    template_name = 'users/document_form.html'
    success_url = reverse_lazy('document_list')

    def get_form(self, *args, **kwargs):
        form = super().get_form(*args, **kwargs)
        form.fields['projet'].queryset = Projet.objects.filter(owner=self.request.user)
        return form

class DocumentUpdateView(LoginRequiredMixin, UpdateView):
    model = Document
    fields = ['projet', 'titre', 'fichier', 'description']
    template_name = 'users/document_form.html'
    success_url = reverse_lazy('document_list')

    def get_queryset(self):
        return Document.objects.filter(projet__owner=self.request.user)

class DocumentDeleteView(LoginRequiredMixin, DeleteView):
    model = Document
    template_name = 'users/document_confirm_delete.html'
    success_url = reverse_lazy('document_list')

    def get_queryset(self):
        return Document.objects.filter(projet__owner=self.request.user)

# Exemple de génération PDF
@login_required
def download_document_pdf(request, doc_id):
    document = get_object_or_404(Document, id=doc_id)
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="{document.nom}.pdf"'
    p = canvas.Canvas(response)
    p.drawString(100, 800, f"Document: {document.nom}")
    p.drawString(100, 780, f"Description: {document.description}")
    p.showPage()
    p.save()
    return response

# Pour un document individuel
@login_required
def download_document_pdf(request, doc_id):
    document = get_object_or_404(Document, id=doc_id, projet__owner=request.user)
    
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="{document.titre}.pdf"'
    
    # Création du PDF avec ReportLab
    doc = SimpleDocTemplate(response, pagesize=letter)
    styles = getSampleStyleSheet()
    story = []
    
    # Titre
    story.append(Paragraph(f"Document: {document.titre}", styles['Title']))
    story.append(Spacer(1, 12))
    
    # Métadonnées
    story.append(Paragraph(f"<b>Projet:</b> {document.projet.titre}", styles['Normal']))
    story.append(Paragraph(f"<b>Date d'ajout:</b> {document.date_ajout.strftime('%d/%m/%Y')}", styles['Normal']))
    story.append(Spacer(1, 12))
    
    # Description
    if document.description:
        story.append(Paragraph("<b>Description:</b>", styles['Normal']))
        story.append(Paragraph(document.description, styles['Normal']))
        story.append(Spacer(1, 12))
    
    # Lien de téléchargement
    if document.fichier:
        full_url = request.build_absolute_uri(document.fichier.url)
        story.append(Paragraph(f"<b>Fichier original:</b> {full_url}", styles['Normal']))
    
    doc.build(story)
    return response

@login_required
def download_document_word(request, doc_id):
    document = get_object_or_404(Document, id=doc_id, projet__owner=request.user)
    
    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.wordprocessingml.document')
    response['Content-Disposition'] = f'attachment; filename="{document.titre}.docx"'
    
    doc = docx.Document()
    
    # Titre
    doc.add_heading(document.titre, 0)
    
    # Métadonnées
    doc.add_paragraph(f"Projet: {document.projet.titre}")
    doc.add_paragraph(f"Date d'ajout: {document.date_ajout.strftime('%d/%m/%Y')}")
    
    # Description
    if document.description:
        doc.add_heading('Description', level=1)
        doc.add_paragraph(document.description)
    
    # Lien de téléchargement
    if document.fichier:
        doc.add_heading('Fichier original', level=1)
        full_url = request.build_absolute_uri(document.fichier.url)
        doc.add_paragraph(full_url)
    
    buffer = BytesIO()
    doc.save(buffer)
    buffer.seek(0)
    response.write(buffer.read())
    return response

@login_required
def download_document_excel(request, doc_id):
    document = get_object_or_404(Document, id=doc_id, projet__owner=request.user)
    
    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = f'attachment; filename="{document.titre}.xlsx"'
    
    wb = Workbook()
    ws = wb.active
    ws.title = "Document"
    
    # En-têtes
    ws['A1'] = "Champ"
    ws['B1'] = "Valeur"
    
    # Données
    data = [
        ("Titre", document.titre),
        ("Projet", document.projet.titre),
        ("Date d'ajout", document.date_ajout.strftime('%d/%m/%Y')),
        ("Description", document.description),
        ("Fichier", request.build_absolute_uri(document.fichier.url) if document.fichier else "")
    ]
    
    for idx, (field, value) in enumerate(data, start=2):
        ws[f'A{idx}'] = field
        ws[f'B{idx}'] = value
    
    with BytesIO() as buffer:
        wb.save(buffer)
        response.write(buffer.getvalue())
    
    return response

@login_required
# Vue principale d'export
def export_documents_list(request, format_type):
    documents = Document.objects.filter(projet__owner=request.user).select_related('projet')
    
    if format_type == 'pdf':
        return generate_pdf_list(documents, request)
    elif format_type == 'word':
        return generate_word_list(documents, request)
    elif format_type == 'excel':
        return generate_excel_list(documents, request)
    else:
        return HttpResponse("Format non supporté", status=400)

# Génération PDF
def generate_pdf_list(documents, request):
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="liste_documents.pdf"'
    
    doc_pdf = SimpleDocTemplate(response, pagesize=letter)
    styles = getSampleStyleSheet()
    story = []

    # Titre
    story.append(Paragraph("Liste des Documents", styles['Title']))
    story.append(Spacer(1, 12))

    # Tableau
    data = [['Titre', 'Projet', 'Date', 'Description']]
    for doc_item in documents:
        data.append([
            doc_item.titre,
            doc_item.projet.titre if doc_item.projet else '',
            doc_item.date_ajout.strftime('%d/%m/%Y') if doc_item.date_ajout else '',
            (doc_item.description[:50] + '...') if doc_item.description else ''
        ])
    
    table = Table(data)
    table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.grey),
        ('TEXTCOLOR', (0,0), (-1,0), colors.whitesmoke),
        ('ALIGN', (0,0), (-1,-1), 'LEFT'),
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
        ('FONTSIZE', (0,0), (-1,0), 10),
        ('BOTTOMPADDING', (0,0), (-1,0), 12),
        ('BACKGROUND', (0,1), (-1,-1), colors.beige),
        ('GRID', (0,0), (-1,-1), 1, colors.black)
    ]))
    
    story.append(table)
    doc_pdf.build(story)
    return response

# Génération Word
def generate_word_list(documents, request):
    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.wordprocessingml.document')
    response['Content-Disposition'] = 'attachment; filename="liste_documents.docx"'
    
    doc_word = docx.Document()
    doc_word.add_heading('Liste des Documents', 0)

    table = doc_word.add_table(rows=1, cols=4)
    table.style = 'Table Grid'

    hdr_cells = table.rows[0].cells
    hdr_cells[0].text = 'Titre'
    hdr_cells[1].text = 'Projet'
    hdr_cells[2].text = 'Date'
    hdr_cells[3].text = 'Description'

    for doc_item in documents:
        row_cells = table.add_row().cells
        row_cells[0].text = doc_item.titre
        row_cells[1].text = doc_item.projet.titre if doc_item.projet else ''
        row_cells[2].text = doc_item.date_ajout.strftime('%d/%m/%Y') if doc_item.date_ajout else ''
        row_cells[3].text = (doc_item.description[:100] + '...') if doc_item.description else ''

    buffer = BytesIO()
    doc_word.save(buffer)
    buffer.seek(0)
    response.write(buffer.read())
    return response

# Génération Excel
def generate_excel_list(documents, request):
    response = HttpResponse(
        content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )
    response['Content-Disposition'] = 'attachment; filename="liste_documents.xlsx"'

    data = []
    for doc_item in documents:
        data.append([
            doc_item.titre,
            doc_item.projet.titre if doc_item.projet else '',
            doc_item.date_ajout.strftime('%Y-%m-%d') if doc_item.date_ajout else '',
            doc_item.description,
            request.build_absolute_uri(doc_item.fichier.url) if doc_item.fichier else ''
        ])
    
    df = pd.DataFrame(data, columns=['Titre', 'Projet', 'Date', 'Description', 'Lien'])

    with BytesIO() as buffer:
        with pd.ExcelWriter(buffer, engine='openpyxl') as writer:
            df.to_excel(writer, index=False, sheet_name='Documents')
            worksheet = writer.sheets['Documents']
            for column_cells in worksheet.columns:
                max_length = 0
                for cell in column_cells:
                    if cell.value:
                        max_length = max(max_length, len(str(cell.value)))
                worksheet.column_dimensions[column_cells[0].column_letter].width = max_length + 2
        response.write(buffer.getvalue())

    return response



# Statistiques exemple
@login_required
def statistiques_view(request):
    # Ex : Nombre d'activités
    labels = ['Activités', 'Indicateurs', 'Évaluations']
    data = [
        Activite.objects.count(),
        Indicateur.objects.count(),
        Evaluation.objects.count(),
    ]
    fig, ax = plt.subplots()
    ax.bar(labels, data)
    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    return HttpResponse(buffer.getvalue(), content_type='image/png')


def access_denied(request):
    return render(request, 'core/403.html', status=403)
    

class UserCreateView(LoginRequiredMixin, CreateView):
    model = CustomUser
    fields = ['username', 'first_name', 'last_name', 'email', 'role', 'organization']
    template_name = 'users/user_create.html'
    success_url = reverse_lazy('membre_list')

    def form_valid(self, form):
        # Générer un mot de passe temporaire
        password = CustomUser.objects.make_random_password()
        user = form.save(commit=False)
        user.set_password(password)
        user.save()
        
        # Ici vous pourriez envoyer un email avec le mot de passe temporaire
        return super().form_valid(form)


User = get_user_model()

class UserListView(ListView):
    model = User
    template_name = "users/user-list.html"