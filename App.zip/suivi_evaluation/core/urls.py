from django.urls import path
from core.decorators import role_required
from . import views

urlpatterns = [
    path('set-theme/', views.set_theme, name='set-theme'),
    path('', views.home_view, name='home'),
    path('dashboard/', views.dashboard_view, name='dashboard'),
    path('statistiques/', role_required('admin', 'manager')(views.statistiques_view), name='statistiques'),
    path('suivi-dashboard/', views.SuiviDashboardView.as_view(), name='suivi_dashboard'),

    #resultats

    path('resultats/', views.ResultatListView.as_view(), name='resultat_list'),
    path('resultats/create/', views.ResultatCreateView.as_view(), name='resultat_create'),
    path('resultats/<int:pk>/', views.ResultatDetailView.as_view(), name='resultat_detail'),
    path('resultats/<int:pk>/update/', views.ResultatUpdateView.as_view(), name='resultat_update'),
    path('resultats/<int:pk>/delete/', views.ResultatDeleteView.as_view(), name='resultat_delete'),

    # Activite
    path('activites/', views.ActiviteListView.as_view(), name='activite_list'),
    path('activites/create/', views.ActiviteCreateView.as_view(), name='activite_create'),
    path('activites/<int:pk>/update/', views.ActiviteUpdateView.as_view(), name='activite_update'),
    path('activites/<int:pk>/delete/', views.ActiviteDeleteView.as_view(), name='activite_delete'),
    path('activites/<int:pk>/', views.ActiviteDetailView.as_view(), name='activite_detail'),


    # Projet
    path('projets/', views.ProjetListView.as_view(), name='projet_list'),
    path('projets/create/', role_required('admin', 'manager')(views.ProjetCreateView.as_view()), name='projet_create'),  # exemple restreint
    path('projets/<int:pk>/', views.ProjetDetailView.as_view(), name='projet_detail'),
    path('projets/<int:pk>/update/', role_required('admin', 'manager')(views.ProjetUpdateView.as_view()), name='projet_update'),  # restreint
    path('projets/<int:pk>/delete/', role_required('admin')(views.ProjetDeleteView.as_view()), name='projet_delete'),  # restreint aux admin

    # Indicateur
    path('indicateurs/', views.IndicateurListView.as_view(), name='indicateur_list'),
    path('indicateurs/create/', role_required('admin', 'manager')(views.IndicateurCreateView.as_view()), name='indicateur_create'),
    path('indicateurs/<int:pk>/update/', role_required('admin', 'manager')(views.IndicateurUpdateView.as_view()), name='indicateur_update'),
    path('indicateurs/<int:pk>/delete/', role_required('admin')(views.IndicateurDeleteView.as_view()), name='indicateur_delete'),

    # SuiviIndicateur
    path('suivis/', views.SuiviIndicateurListView.as_view(), name='suivi_list'),
    path('suivis/create/', role_required('admin', 'manager')(views.SuiviIndicateurCreateView.as_view()), name='suivi_create'),
    path('suivis/<int:pk>/update/', role_required('admin', 'manager')(views.SuiviIndicateurUpdateView.as_view()), name='suivi_update'),
    path('suivis/<int:pk>/delete/', role_required('admin')(views.SuiviIndicateurDeleteView.as_view()), name='suivi_delete'),
    path('suivis/<int:pk>/', views.SuiviIndicateurDetailView.as_view(), name='suiviindicateur_detail'),  # <-- AJOUTEZ CETTE LIGNE

    # MembreEquipe
    # Gestion des membres d'équipe
    path("membres/", views.MembreEquipeListView.as_view(), name="membre_equipe_list"),
    path("membres/ajouter/<int:projet_id>/", views.MembreEquipeCreateView.as_view(), name="membre_equipe_create"),
    path("membres/<int:pk>/modifier/", views.MembreEquipeUpdateView.as_view(), name="membre_equipe_update"),
    path("membres/<int:pk>/supprimer/", views.MembreEquipeDeleteView.as_view(), name="membre_equipe_delete"),
    

    # Vue d’équipe par projet
    path("projets/<int:pk>/equipe/", views.ProjectTeamView.as_view(), name="project_team"),


    
    # Beneficiaire
    path('beneficiaires/', views.BeneficiaireListView.as_view(), name='beneficiaire_list'),
    path('beneficiaires/create/', role_required('admin', 'manager')(views.BeneficiaireCreateView.as_view()), name='beneficiaire_create'),
    path('beneficiaires/<int:pk>/update/', role_required('admin', 'manager')(views.BeneficiaireUpdateView.as_view()), name='beneficiaire_update'),
    path('beneficiaires/<int:pk>/delete/', role_required('admin')(views.BeneficiaireDeleteView.as_view()), name='beneficiaire_delete'),
    path('beneficiaires/<int:pk>/', views.BeneficiaireDetailView.as_view(), name='beneficiaire_detail'),

    # Role
    path('roles/', views.RoleListView.as_view(), name='role_list'),
    path('roles/create/', role_required('admin')(views.RoleCreateView.as_view()), name='role_create'),
    path('roles/<int:pk>/update/', role_required('admin')(views.RoleUpdateView.as_view()), name='role_update'),
    path('roles/<int:pk>/delete/', role_required('admin')(views.RoleDeleteView.as_view()), name='role_delete'),

    # ProjetBeneficiaire
    path('projet-beneficiaires/', views.ProjetBeneficiaireListView.as_view(), name='projet_beneficiaire_list'),
    path('projet-beneficiaires/create/', role_required('admin', 'manager')(views.ProjetBeneficiaireCreateView.as_view()), name='projet_beneficiaire_create'),
    path('projet-beneficiaires/<int:pk>/update/', role_required('admin', 'manager')(views.ProjetBeneficiaireUpdateView.as_view()), name='projet_beneficiaire_update'),
    path('projet-beneficiaires/<int:pk>/delete/', role_required('admin')(views.ProjetBeneficiaireDeleteView.as_view()), name='projet_beneficiaire_delete'),

    # Evaluation
    path('evaluations/', role_required('admin', 'evaluator')(views.EvaluationListView.as_view()), name='evaluation_list'),
    path('evaluations/create/', role_required('admin', 'evaluator')(views.EvaluationCreateView.as_view()), name='evaluation_create'),
    path('evaluations/<int:pk>/update/', role_required('admin', 'evaluator')(views.EvaluationUpdateView.as_view()), name='evaluation_update'),
    path('evaluations/<int:pk>/delete/', role_required('admin')(views.EvaluationDeleteView.as_view()), name='evaluation_delete'),
    path('evaluations/<int:pk>/', role_required('admin', 'evaluator')(views.EvaluationDetailView.as_view()), name='evaluation_detail'),


    # Document
    path('documents/', views.DocumentListView.as_view(), name='document_list'),
    path('documents/create/', role_required('admin', 'manager')(views.DocumentCreateView.as_view()), name='document_create'),
    path('documents/<int:pk>/', views.DocumentDetailView.as_view(), name='document_detail'),
    path('documents/<int:pk>/update/', role_required('admin', 'manager')(views.DocumentUpdateView.as_view()), name='document_update'),
    path('documents/<int:pk>/delete/', role_required('admin')(views.DocumentDeleteView.as_view()), name='document_delete'),

    #Objectif

    path('objectifs/', views.ObjectifListView.as_view(), name='objectif_list'),
    path('objectifs/create/', views.ObjectifCreateView.as_view(), name='objectif_create'),
    path('objectifs/<int:pk>/', views.ObjectifDetailView.as_view(), name='objectif_detail'),
    path('objectifs/<int:pk>/update/', views.ObjectifUpdateView.as_view(), name='objectif_update'),
    path('objectifs/<int:pk>/delete/', views.ObjectifDeleteView.as_view(), name='objectif_delete'),


     # Export des documents
    path('documents/<int:doc_id>/pdf/', views.download_document_pdf, name='document_pdf'),
    path('documents/<int:doc_id>/word/', views.download_document_word, name='document_word'),
    path('documents/<int:doc_id>/excel/', views.download_document_excel, name='document_excel'),
    path('documents/export/pdf/', views.export_documents_list, {'format_type': 'pdf'}, name='export_documents_pdf'),
    path('documents/export/word/', views.export_documents_list, {'format_type': 'word'}, name='export_documents_word'),
    path('documents/export/excel/', views.export_documents_list, {'format_type': 'excel'}, name='export_documents_excel'),
     path('projets/<int:pk>/progression/', views.ProjetProgressionView.as_view(), name='projet_progression'),
    path('update-progression/', views.UpdateProgressionView.as_view(), name='update_progression'),

    path('activites/<int:activite_pk>/etapes/create/', views.EtapeCreateView.as_view(), name='etape_create'),
    path('etapes/<int:pk>/toggle/', views.EtapeToggleView.as_view(), name='etape_toggle'),
]
   




