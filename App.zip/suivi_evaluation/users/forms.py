from django import forms
from django.contrib.auth.forms import UserCreationForm, UserChangeForm, AuthenticationForm
from django.db.models import Q
from .models import CustomUser, RoleUtilisateur, Team
from core.models import MembreEquipe, Projet, Evaluation

# -------------------------
# Styles CSS pour les inputs
# -------------------------
INPUT_STYLE = {
    'class': 'appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm'
}

# -------------------------
# Formulaire d'authentification
# -------------------------
class CustomAuthenticationForm(AuthenticationForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['username'].widget.attrs.update(INPUT_STYLE)
        self.fields['password'].widget.attrs.update(INPUT_STYLE)

# -------------------------
# Formulaire de création utilisateur
# -------------------------
class CustomUserCreationForm(UserCreationForm):
    class Meta:
        model = CustomUser
        fields = ['username', 'email', 'password1', 'password2', 'role', 'organization', 'team']
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        # Appliquer les styles
        for field in self.fields.values():
            field.widget.attrs.update(INPUT_STYLE)
        
        # Afficher TOUS les rôles dans le formulaire admin
        if 'role' in self.fields:
            self.fields['role'].queryset = RoleUtilisateur.objects.all()

class CustomUserChangeForm(UserChangeForm):
    password = None
    
    class Meta:
        model = CustomUser
        fields = ['username', 'email', 'first_name', 'last_name', 
                 'role', 'organization', 'team', 'is_active', 'is_staff', 'is_approved']
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        # Appliquer les styles
        for field in self.fields.values():
            field.widget.attrs.update(INPUT_STYLE)
        
        # Afficher TOUS les rôles dans le formulaire admin
        if 'role' in self.fields:
            self.fields['role'].queryset = RoleUtilisateur.objects.all()
            

# -------------------------
# Formulaire d'évaluation
# -------------------------
class EvaluationForm(forms.ModelForm):
    class Meta:
        model = Evaluation
        fields = ['projet', 'type_evaluation', 'date', 'note', 'commentaires']
        widgets = {
            'date': forms.DateInput(attrs={'type': 'date', **INPUT_STYLE}),
            'commentaires': forms.Textarea(attrs={'rows': 3, **INPUT_STYLE}),
        }

    def __init__(self, *args, **kwargs):
        self.request = kwargs.pop('request', None)
        super().__init__(*args, **kwargs)

        if self.request and hasattr(self.request, 'user'):
            if not getattr(self.request.user, 'is_admin', False):
                self.fields['projet'].queryset = Projet.objects.filter(
                    Q(owner=self.request.user) | 
                    Q(membres=self.request.user)
                ).distinct()
        else:
            self.fields['projet'].queryset = Projet.objects.none()


# -------------------------
# Formulaire MembreEquipe
# -------------------------
class MembreEquipeForm(forms.ModelForm):
    class Meta:
        model = MembreEquipe
        fields = ['projet', 'user', 'role']
        widgets = {
            'role': forms.Select(attrs=INPUT_STYLE),
        }

    def __init__(self, *args, **kwargs):
        self.request = kwargs.pop('request', None)
        super().__init__(*args, **kwargs)

        if not (self.request and self.request.user.is_admin()):
            self.fields['projet'].queryset = Projet.objects.filter(
                Q(owner=self.request.user) | Q(membres__user=self.request.user)
            ).distinct()

# -------------------------
# Formulaire de création d'équipe
# -------------------------
class TeamCreationForm(forms.ModelForm):
    class Meta:
        model = Team
        fields = ['name', 'description', 'leader']
        widgets = {
          
            'name': forms.TextInput(attrs=INPUT_STYLE),
            'description': forms.Textarea(attrs={'rows': 3, **INPUT_STYLE}),
            'leader': forms.Select(attrs=INPUT_STYLE)
        }

    def __init__(self, *args, **kwargs):
        self.request = kwargs.pop('request', None)
        super().__init__(*args, **kwargs)
        
        # Leader obligatoire
        self.fields['leader'].required = True

        # Si ce n'est pas un admin, retirer le champ leader
        if not (self.request and self.request.user.is_admin()):
            self.fields.pop('leader', None)
