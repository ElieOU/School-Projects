from django.urls import path
from .views import login_view, logout_view, register_view, UserCreateView, UserListView, UserUpdateView, TeamManagementView

urlpatterns = [
    path('auth/login/', login_view, name='login'),
    path('auth/logout/', logout_view, name='logout'),
    path('auth/register/', register_view, name='register'),
    path('auth/users/', UserListView.as_view(), name='user_list'),
    path('auth/users/create/', UserCreateView.as_view(), name='user_create'),
    path('auth/users/<int:pk>/update/', UserUpdateView.as_view(), name='user_update'),
    path('auth/teams/', TeamManagementView.as_view(), name='team_management'),
]