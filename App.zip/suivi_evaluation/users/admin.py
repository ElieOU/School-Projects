from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.contrib.auth.forms import UserCreationForm
from .models import CustomUser, RoleUtilisateur, Team
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.contrib.auth.forms import UserCreationForm, UserChangeForm
from django.utils.translation import gettext_lazy as _
from .models import CustomUser, RoleUtilisateur, Team
from .forms import CustomUserCreationForm, CustomUserChangeForm


class CustomUserCreationForm(UserCreationForm):
    """Marque les superusers créés par la commande"""
    def save(self, commit=True):
        user = super().save(commit=False)
        user._is_superuser = True  # Flag spécial
        if commit:
            user.save()
        return user


class CustomUserAdmin(UserAdmin):
    form = CustomUserChangeForm
    add_form = CustomUserCreationForm
    
    list_display = ('username', 'email', 'get_role_display', 'organization', 'team', 'is_staff', 'is_active', 'is_approved')
    list_filter = ('role', 'is_staff', 'is_active', 'is_approved', 'team')
    search_fields = ('username', 'email', 'first_name', 'last_name', 'organization')
    ordering = ('username',)
    
    fieldsets = (
        (None, {'fields': ('username', 'password')}),
        (_('Personal info'), {'fields': ('first_name', 'last_name', 'email')}),
        (_('Permissions'), {
            'fields': ('is_active', 'is_staff', 'is_approved', 'groups', 'user_permissions'),
        }),
        (_('Important dates'), {'fields': ('last_login', 'date_joined')}),
        (_('Organization info'), {'fields': ('role', 'organization', 'team')}),
    )
    
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('username', 'email', 'password1', 'password2', 'role', 'organization', 'team'),
        }),
    )
    
    def get_role_display(self, obj):
        return obj.role.get_code_display() if obj.role else ''
    get_role_display.short_description = _('Rôle')
    
    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        # Afficher TOUS les rôles dans l'admin
        if 'role' in form.base_fields:
            form.base_fields['role'].queryset = RoleUtilisateur.objects.all()
        return form

@admin.register(RoleUtilisateur)
class RoleUtilisateurAdmin(admin.ModelAdmin):
    list_display = ('get_code_display', 'description')
    search_fields = ('code', 'description')
    
    def get_code_display(self, obj):
        return obj.get_code_display()
    get_code_display.short_description = _('Rôle')


@admin.register(Team)
class TeamAdmin(admin.ModelAdmin):
    list_display = ('name', 'get_leader_display', 'description')
    list_filter = ('leader',)
    search_fields = ('name', 'description')
    raw_id_fields = ('leader',)
    
    def get_leader_display(self, obj):
        return obj.leader.username if obj.leader else ''
    get_leader_display.short_description = _('Leader')

admin.site.register(CustomUser, CustomUserAdmin)