# users/models.py
from django.contrib.auth.models import AbstractUser
from django.db import models
from django.utils.translation import gettext_lazy as _


class RoleUtilisateur(models.Model):
    """Modèle pour les rôles personnalisés"""

    class Codes(models.TextChoices):
        ADMIN = 'admin', _('Administrateur Système')
        MANAGER = 'manager', _('Manager')
        PARTNER = 'partenaire', _('Partenaire technique')
        EVALUATOR = 'evaluator', _('Évaluateur')
        MEMBER = 'member', _('Membre standard')

    code = models.CharField(
        max_length=20,
        choices=Codes.choices,
        unique=True
    )
    description = models.CharField(max_length=255, blank=True)

    def __str__(self):
        return self.get_code_display()


class Team(models.Model):
    """Modèle d'équipe"""
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    leader = models.ForeignKey(
        'CustomUser',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='led_teams'
    )

    def __str__(self):
        return self.name


class CustomUser(AbstractUser):
    """Utilisateur personnalisé avec intégration des rôles"""

    role = models.ForeignKey(
        RoleUtilisateur,
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )

    organization = models.CharField(
        max_length=100,
        blank=True,
        null=True
    )

    team = models.ForeignKey(
        Team,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='members'
    )

    is_approved = models.BooleanField(default=True)

    # ⚠️ SUPPRESSION de is_superuser (on ne l’utilise plus)

    def save(self, *args, **kwargs):
        """Si l'utilisateur est ADMIN => il est staff automatiquement"""
        if self.role and self.role.code == RoleUtilisateur.Codes.ADMIN:
            self.is_staff = True
        super().save(*args, **kwargs)

    @property
    def is_admin(self):
        """Raccourci pour savoir si c'est un administrateur"""
        return self.role and self.role.code == RoleUtilisateur.Codes.ADMIN

    # ✅ Un admin = a tous les droits
    def has_perm(self, perm, obj=None):
        if self.is_admin:
            return True
        return super().has_perm(perm, obj)

    def has_module_perms(self, app_label):
        if self.is_admin:
            return True
        return super().has_module_perms(app_label)
