from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.contrib import messages
from django.shortcuts import render, redirect
from django.views.generic import CreateView, ListView, UpdateView, TemplateView
from django.urls import reverse_lazy
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.db import models
from .models import CustomUser, RoleUtilisateur, Team
from .forms import CustomUserCreationForm, CustomUserChangeForm, TeamCreationForm

# -------------------------
# MIXINS
# -------------------------
class AdminRequiredMixin(LoginRequiredMixin, UserPassesTestMixin):
    """Vérifie que l'utilisateur est administrateur"""
    permission_denied_message = "Accès réservé aux administrateurs"

    def test_func(self):
        return self.request.user.is_admin()

    def handle_no_permission(self):
        if self.raise_exception or self.request.user.is_authenticated:
            messages.error(self.request, self.permission_denied_message)
            return redirect('dashboard')
        return super().handle_no_permission()


class ManagerRequiredMixin(LoginRequiredMixin, UserPassesTestMixin):
    """Vérifie que l'utilisateur est manager ou admin"""
    permission_denied_message = "Permissions insuffisantes pour accéder à cette page"

    def test_func(self):
        user = self.request.user
        return (
            user.is_admin() or
            (user.role and user.role.code == RoleUtilisateur.Codes.MANAGER)
        )


# -------------------------
# VUES AUTHENTIFICATION
# -------------------------
def login_view(request):
    """Vue de connexion basique avec nom d'utilisateur et mot de passe"""
    if request.user.is_authenticated:
        return redirect('dashboard')

    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)

        if user:
            login(request, user)
            return redirect('dashboard')
        messages.error(request, "Nom d'utilisateur ou mot de passe incorrect")

    return render(request, 'users/login.html', {'title': 'Connexion'})


def register_view(request):
    """Vue d'inscription pour les nouveaux utilisateurs"""
    if request.user.is_authenticated:
        return redirect('dashboard')

    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)

            # Vérifie si l'utilisateur a choisi un rôle ou assigne le rôle MEMBER par défaut
            if not user.role:
                member_role, _ = RoleUtilisateur.objects.get_or_create(
                    code=RoleUtilisateur.Codes.MEMBER,
                    defaults={'description': 'Membre standard'}
                )
                user.role = member_role

            # Auto-approve si c'est un membre standard
            user.is_approved = user.role.code == RoleUtilisateur.Codes.MEMBER
            user.save()

            messages.success(
                request,
                "Votre compte a été créé avec succès." +
                (" Il est en attente d'approbation." if not user.is_approved else "")
            )
            return redirect('login')
    else:
        form = CustomUserCreationForm()

    return render(request, 'users/register.html', {
        'form': form,
        'title': 'Créer un compte'
    })


@login_required
def logout_view(request):
    """Vue de déconnexion"""
    username = request.user.username
    logout(request)
    messages.success(request, f"Vous avez été déconnecté ({username}).")
    return redirect('login')


# -------------------------
# VUES UTILISATEURS
# -------------------------
class UserCreateView(AdminRequiredMixin, CreateView):
    model = CustomUser
    form_class = CustomUserCreationForm
    template_name = 'users/user_form.html'
    success_url = reverse_lazy('user_list')

    def form_valid(self, form):
        user = form.save(commit=False)

        # Définit un rôle par défaut si nécessaire
        if not user.role:
            member_role, _ = RoleUtilisateur.objects.get_or_create(
                code=RoleUtilisateur.Codes.MEMBER,
                defaults={'description': 'Membre standard'}
            )
            user.role = member_role

        # Auto-approve si admin
        if user.role.code == RoleUtilisateur.Codes.ADMIN:
            user.is_approved = True

        user.save()

        messages.success(
            self.request,
            f"Utilisateur {user.email} créé avec succès. " +
            ("Le compte est activé." if user.is_approved else "En attente d'approbation.")
        )
        return redirect(self.success_url)


class UserListView(AdminRequiredMixin, ListView):
    model = CustomUser
    template_name = 'users/user_list.html'
    context_object_name = 'users'
    paginate_by = 25
    ordering = ['-date_joined']

    def get_queryset(self):
        queryset = super().get_queryset()
        role_filter = self.request.GET.get('role')
        search_query = self.request.GET.get('search')

        if role_filter:
            queryset = queryset.filter(role=role_filter)

        if search_query:
            queryset = queryset.filter(
                models.Q(username__icontains=search_query) |
                models.Q(email__icontains=search_query) |
                models.Q(first_name__icontains=search_query) |
                models.Q(last_name__icontains=search_query)
            )
        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['roles'] = RoleUtilisateur.Codes.choices
        context['current_role'] = self.request.GET.get('role', '')
        context['search_query'] = self.request.GET.get('search', '')
        return context


class UserUpdateView(AdminRequiredMixin, UpdateView):
    model = CustomUser
    form_class = CustomUserChangeForm
    template_name = 'users/user_form.html'
    success_url = reverse_lazy('user_list')

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs['is_admin'] = True
        return kwargs

    def form_valid(self, form):
        response = super().form_valid(form)
        messages.success(self.request, f"Utilisateur {self.object.email} mis à jour.")
        return response


# -------------------------
# VUES ÉQUIPES
# -------------------------
class TeamManagementView(ManagerRequiredMixin, TemplateView):
    template_name = 'users/team_management.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        user = self.request.user

        if user.is_admin():
            context['teams'] = Team.objects.all().prefetch_related('members')
        else:
            context['teams'] = Team.objects.filter(
                models.Q(leader=user) | models.Q(members=user)
            ).distinct().prefetch_related('members')

        context['team_form'] = TeamCreationForm(initial={'leader': user})
        return context


class TeamCreateView(ManagerRequiredMixin, CreateView):
    model = Team
    form_class = TeamCreationForm
    template_name = 'users/team_form.html'
    success_url = reverse_lazy('team_management')

    def form_valid(self, form):
        team = form.save()
        messages.success(self.request, f"Équipe {team.name} créée avec succès.")
        return super().form_valid(form)


# -------------------------
# PROFIL UTILISATEUR
# -------------------------
@method_decorator(login_required, name='dispatch')
class UserProfileView(UpdateView):
    model = CustomUser
    fields = ['first_name', 'last_name', 'email', 'organization']
    template_name = 'users/profile.html'
    success_url = reverse_lazy('profile')

    def get_object(self):
        return self.request.user

    def form_valid(self, form):
        messages.success(self.request, "Profil mis à jour avec succès.")
        return super().form_valid(form)

