from django.core.exceptions import PermissionDenied
from django.contrib.auth.mixins import UserPassesTestMixin

class AdminRequiredMixin(UserPassesTestMixin):
    """Vérifie que l'utilisateur est administrateur"""
    def test_func(self):
        return self.request.user.is_admin()
    
    def handle_no_permission(self):
        raise PermissionDenied("Vous n'avez pas les permissions nécessaires")